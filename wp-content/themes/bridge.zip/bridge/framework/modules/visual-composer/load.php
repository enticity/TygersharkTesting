<?php

if (qode_visual_composer_installed()) {
	include_once QODE_FRAMEWORK_MODULES_ROOT_DIR.'/visual-composer/visual-composer-config.php';
}