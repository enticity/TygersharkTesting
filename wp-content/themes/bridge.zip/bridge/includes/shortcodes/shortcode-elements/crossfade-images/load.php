<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/crossfade-images/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/crossfade-images/crossfade-images.php';