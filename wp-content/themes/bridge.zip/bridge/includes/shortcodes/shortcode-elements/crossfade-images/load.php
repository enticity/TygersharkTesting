<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/crossfade-images/crossfade-images.php';