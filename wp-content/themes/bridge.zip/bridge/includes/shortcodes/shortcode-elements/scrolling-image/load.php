<?php
include_once QODE_SHORTCODES_ROOT_DIR.'/scrolling-image/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/scrolling-image/scrolling-image.php';