<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/cards-gallery/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/cards-gallery/cards-gallery.php';