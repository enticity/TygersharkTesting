<?php

include_once QODE_SHORTCODES_ROOT_DIR.'/advanced-call-to-action/functions.php';
include_once QODE_SHORTCODES_ROOT_DIR.'/advanced-call-to-action/advanced-call-to-action.php';