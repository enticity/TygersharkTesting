<?php

require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-tabs/functions.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-tabs/advanced-tabs.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-tabs/advanced-tab.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-tabs/options-map/map.php';
require_once QODE_SHORTCODES_ROOT_DIR.'/advanced-tabs/custom-styles/custom-styles.php';